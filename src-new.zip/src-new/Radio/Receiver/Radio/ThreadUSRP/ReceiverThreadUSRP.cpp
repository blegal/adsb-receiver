#include "ReceiverThreadUSRP.hpp"
#include <iostream>
#include <vector>
#include <algorithm>
#include <future>
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//

ReceiverThreadUSRP::ReceiverThreadUSRP(float s_fc, float s_fe)
    : Receiver(s_fc, s_fe), buff(sizeof(complex<float>) * s_fe ), // donc moins que cela car on parle de (complexes,float)
    cthread(&ReceiverThreadUSRP::fetch_values, this)
{
    printf("(II) Allocating receiver\n");
    acq_ready = false;

    fc = s_fc;
    fe = s_fe;

    string usrp_addr("type=b200");                 // L'adresse de l'USRP est écrite en dur pour l'instant
    usrp = uhd::usrp::multi_usrp::make(usrp_addr); // Initialisation de l'USRP
    printf("(II) End of receiver allocation\n");
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
ReceiverThreadUSRP::~ReceiverThreadUSRP()
{
    usrp.reset();
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::initialize()
{
    printf("(II) initialization of receiver\n");
    usrp->set_clock_source("internal");
	usrp->set_rx_rate(fe);                         // Set de la fréquence d'échantillonnage
	usrp->set_rx_freq(fc);             // Set de la fréquence porteuse
	usrp->set_rx_antenna("RX2");

    uhd::stream_args_t stream_args("fc32", "sc12");

    // Type des données à échantillonner (ici complexes float 64 - 32 bits par voie)
	rx_stream = usrp->get_rx_stream(stream_args);    // Pointeur sur les data reçues

    cout << "[Thread-USRP] Clock source is set to        : internal]" << endl;
    cout << "[Thread-USRP] Sampling Rate set to         : " << usrp->get_rx_rate() << " MHz" << endl;
    cout << "[Thread-USRP] Central Frequency set to     : " << usrp->get_rx_freq() << " MHz" << endl;
    cout << "[Thread-USRP] Receiver gain is set to      : " << usrp->get_rx_gain() << " dB" << endl;
    cout << "[Thread-USRP] Reception antenna is set to  : RX2" << endl;
    cout << "[Thread-USRP] Sample data format is set to : fc32" << endl;
    cout << "[Thread-USRP] #channels for rx_stream      : " << rx_stream->get_num_channels() << " channel(s)" << endl;
    cout << "[Thread-USRP] #samples in rx_stream buffer : " << rx_stream->get_max_num_samps() << " IQs" << endl;
    printf("(II) end of initialization of receiver\n");

    mutex_acq.unlock(); // on debloque le mutex et donc la reception
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::fetch_values()
{
    mutex_acq.lock();   // On le prends 2 fois pour se
    mutex_acq.lock();   // bloquer en attendant la fin de l'initialisation

    const int buffSize = 65536;
    ibuffer.resize( buffSize );

    while( true )
    {
        uhd::rx_metadata_t md; // Des metadata
        int nSamples = rx_stream->recv(ibuffer.data(), ibuffer.size(), md, 100.0); // 2 secondes de timeout...
        if( nSamples != ibuffer.size() )
        {
            printf("oups !\n");
            float fill = 100.0f * (float)buff.NumElements() / (float)buff.Capacity();
            printf("fill = %f\n", fill);
            printf("asked %d received %d\n", ibuffer.size(), nSamples);
        }

        if (md.error_code == uhd::rx_metadata_t::ERROR_CODE_TIMEOUT) {
            std::cout << boost::format("Error a timeout appeared while streaming...") << std::endl;
            _alive = false;
            break;
        }

        if (md.error_code == uhd::rx_metadata_t::ERROR_CODE_OVERFLOW) {
            float fill = 100.0f * (float)buff.NumElements() / (float)buff.Capacity();
            printf("fill = %f\n", fill);
            std::cerr << boost::format("Got an overflow indication.\n");
            _alive = false;
            break;
        }

        if (md.error_code != uhd::rx_metadata_t::ERROR_CODE_NONE) {
            std::string error = str(boost::format("Receiver error: %s") % md.strerror());
            _alive = false;
            break;
        }

        const int nBytes = (sizeof(complex<float>) * buffSize);
        const int to_receive = buff.NumFreeElements();
        if( to_receive < nBytes )
        {
            printf("(EE) Buffer overflow during reception...\n");
            exit( EXIT_FAILURE );
        }

        const int nWrite = buff.Write( (int8_t *)ibuffer.data(), nBytes );
        if( nWrite != nBytes )
        {
            printf("(EE) An error appear during the data writing in the buffer...\n");
            exit( EXIT_FAILURE );
        }
    }
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
bool ReceiverThreadUSRP::reception(vector<complex<float> >& buffer, const int coverage)
{
//    float fill = 100.0f * (float)buff.NumElements() / (float)buff.Capacity();
//    printf("fill = %f\n", fill);


    const int nOffset  = buffer.size() - coverage;

    // Debut du vieillissement du buffer
    for(int loop = 0; loop < coverage; loop += 1)
    {
        buffer[loop] = buffer[nOffset + loop];
    }
    // Fin du vieillissement du buffer

    const int toRead = sizeof(complex<float>) * (buffer.size() - coverage); // le buffer parle en bytes (et non en nombre de couples I/Q)
    if( toRead > buff.Capacity() )                                          // N : est exrimé en nombre de bytes (et non en nombre de couples I/Q)
    {
        fprintf(stderr, "ReceiverThreadUSRP::reception() failed: the number of data to read is higher than buffer size (%d)\n", toRead);
        exit( EXIT_FAILURE );
    }

//    printf("requesting %d bytes / %d bytes\n", toRead, buff.Capacity());
//    printf("available %d bytes\n", buff.NumElements());

    //
    // On se met en attente du bon nombre de données
    //
    while(buff.NumElements() < toRead)     // les 2 sont exprimés en nombre de samples
    {
        usleep(500); // queue empty
    }

    int nRead = buff.Read( (int8_t*)(buffer.data() + coverage), toRead);
    if( nRead != toRead )
    {
        fprintf(stderr, "ReceiverHackRF::reception() failed: the number of data to read is different than the resquest (%d)\n", toRead);
        exit( EXIT_FAILURE );
    }

//    mutex_acq.unlock();
//    printf("read finished\n");
//    printf("available %d bytes\n", buff.NumElements());

    return _alive;
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::reset()
{
	usrp.reset();
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::start_engine()
{
    std::cout << "[ Thread-USRP engine begin  ]" << std::endl;
    usrp->issue_stream_cmd(uhd::stream_cmd_t::STREAM_MODE_START_CONTINUOUS);
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::stop_engine()
{
    std::cout << "[ Thread-USRP engine end ]" << std::endl;
    usrp->issue_stream_cmd(uhd::stream_cmd_t::STREAM_MODE_STOP_CONTINUOUS);
    rx_stream.reset();
}
//
//
//
////////////////////////////////////////////////////////////////////////////////
//
//
//
void ReceiverThreadUSRP::set_rx_gain(const float gain_value)
{
    usrp->set_rx_gain(gain_value);
    std::cout << "[ Thread-USRP: Changing reception gain : " << usrp->get_rx_gain() << " dB ]" << std::endl;
}
