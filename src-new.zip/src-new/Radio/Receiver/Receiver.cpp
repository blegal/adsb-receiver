#include "Receiver.hpp"

Receiver::Receiver(float s_fc, float s_fe){
    fc         = s_fc;
    fe         = s_fe;
    _alive     = true;
}


Receiver::~Receiver()
{

}

bool Receiver::alive()
{
    return _alive;
}
