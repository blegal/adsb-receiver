#include "CplxModule.hpp"


CplxModule::CplxModule()
{

}

CplxModule::~CplxModule()
{

}
