//!
//! @file 				RingBuff.hpp
//! @author 			Geoffrey Hunter <gbmhunter@gmail.com> (www.mbedded.ninja)
//! @created 			2013-07-30
//! @last-modified		2014-09-26
//! @brief 				Implements the ring buffer.
//! @details
//!						I upgraded the engine to make it fast :-)
//!						Bertrand LE GAL (2021)
#ifndef MRING_BUFF_RING_BUFF_H
#define MRING_BUFF_RING_BUFF_H

#include <cstdint> 

class RingBuff
{
public:

    RingBuff(const int capacity);

    ~RingBuff();

    int Write(const int8_t* buff, int numBytes);

    int Read(int8_t* buff, int numBytes);

    void Clear();

    int Capacity() const;

    int NumElements() const;
    int NumFreeElements() const;

private:
    //! @brief		Pointer to buffer. Memory allocated in constructor.
    int8_t* buffMemPtr;

    //! @brief		The size of the buffer (in bytes). Set by Buffer().
    int capacity;

    //! @brief		The head position, measured in bytes from the start of the buffer (bufPtr).
    //! @details	This is the next element to write to.
    int headPos;

    //! @brief		The tail position, measured in bytes from the start of the buffer (bufPtr).
    //! @details	This is the next element to read from.
    int tailPos;

    //! @brief		Keeps track of the number of elements in the memory buffer.
    //! @details	Incremented by 1 for every element written to the buffer, decremented
    //!				by 1 for every element read from the buffer.
    int numElements;

};

#endif
