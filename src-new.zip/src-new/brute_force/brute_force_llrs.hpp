#ifndef _brute_force_llrs_
#define _brute_force_llrs_



#endif