#ifndef _brute_force_2x_
#define _brute_force_2x_

#include <cstdint>
#include <vector>

using namespace std;

extern bool try_brute_force_2x(vector<uint8_t>& vec_pack, vector<uint8_t>& vec_demod, vector<uint8_t>& vec_sync);

#endif