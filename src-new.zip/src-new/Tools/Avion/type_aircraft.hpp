#ifndef _type_aircraft_
#define _type_aircraft_

extern const char* toCodeName(const int value);
extern int         toCode    (const int tc, const int ca);

#endif